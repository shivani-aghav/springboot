package com.te.springfrontbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringfrontbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
