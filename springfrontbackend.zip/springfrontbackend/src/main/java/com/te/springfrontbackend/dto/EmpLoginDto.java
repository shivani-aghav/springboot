package com.te.springfrontbackend.dto;

import lombok.Data;

@Data
public class EmpLoginDto {

	private String empId;
	private String password;
	
}
