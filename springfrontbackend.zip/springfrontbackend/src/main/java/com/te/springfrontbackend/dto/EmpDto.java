package com.te.springfrontbackend.dto;

import lombok.Data;

@Data
public class EmpDto {

	private String empId;
	private String empName;
	private String emailId;
	private String password;
}
