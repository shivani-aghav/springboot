//package com.te.employeemanagementsystem.sms;
//
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Configuration;
//
//import lombok.Data;
//
//@Configuration
//@ConfigurationProperties(prefix =  "twilio")
//@Data
//public class TwilioProperties {
//
//	private String account_sid;
//	private String auth_token;
//	private String phone_number;
//}
