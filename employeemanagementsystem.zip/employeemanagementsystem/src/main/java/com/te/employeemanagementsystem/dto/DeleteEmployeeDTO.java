package com.te.employeemanagementsystem.dto;

import lombok.Data;

@Data
public class DeleteEmployeeDTO {

	private Integer empId;
	
}
