package com.te.jasper_employeemangementsystem.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.jasper_employeemangementsystem.dto.ResponseDTO;
import com.te.jasper_employeemangementsystem.entity.Employee;
import com.te.jasper_employeemangementsystem.exception.EmployeeNotFoundException;
import com.te.jasper_employeemangementsystem.service.EmployeeService;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@RestController
@RequestMapping("/mentor")
public class MentorController {

	@Autowired
	private EmployeeService service;
 
	private DataSource dataSource;


	@GetMapping("/getAll")
	public ResponseEntity<ResponseDTO> getAll() throws FileNotFoundException, JRException, SQLException{
		List<Employee> all = service.getAll();
		if (all==null) {
			throw new EmployeeNotFoundException("Data Not Found");
		}
		System.out.println("ala ka");
		String filePath = "D:\\TECHNO ELEVATE\\SpringBoot\\jasper_employeemangementsystem\\src\\main\\resources\\jasper.jrxml";
		File file = ResourceUtils.getFile(filePath);
		JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
		JRBeanCollectionDataSource jrBeanCollectionDataSource = new JRBeanCollectionDataSource(all);
		HashMap<String, Object> map = new HashMap<>();
		JasperPrint print = JasperFillManager.fillReport(jasperReport, map,jrBeanCollectionDataSource);
		JasperExportManager.exportReportToPdfFile(print, "D:\\TECHNO ELEVATE\\Jasper\\jasperOne.pdf");
		return new ResponseEntity<>(new ResponseDTO(false, "Data Found", ""), HttpStatus.OK);
//		JasperReport compileReport = JasperCompileManager.compileReport(new FileInputStream( "D:\\TECHNO ELEVATE\\SpringBoot\\jasper_employeemangementsystem\\src\\main\\resources\\jasper-ems.jrxml"));
//		HashMap<String, Object> map = new HashMap<>();
//		JasperPrint fillprint = JasperFillManager.fillReport(compileReport, map,dataSource.getConnection());
//		JasperExportManager.exportReportToPdfFile(fillprint,  "D:\\TECHNO ELEVATE\\JasperReport\\Jasper.pdf");
//		return new ResponseEntity<>(new ResponseDTO(false, "Data Found", ""), HttpStatus.OK);
	}
}
