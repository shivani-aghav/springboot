package com.te.jasper_employeemangementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JasperEmployeemangementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(JasperEmployeemangementsystemApplication.class, args);
	}

}
