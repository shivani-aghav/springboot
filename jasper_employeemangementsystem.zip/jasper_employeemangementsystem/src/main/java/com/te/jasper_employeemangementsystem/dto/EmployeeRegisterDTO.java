package com.te.jasper_employeemangementsystem.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeRegisterDTO {

	
	private String employeeId;
	private String empName;
	private String empDesignation;
	private String email;
	private Date DOJ;
	private long phoneNumber;
}
